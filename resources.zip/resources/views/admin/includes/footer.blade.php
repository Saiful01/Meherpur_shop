<script src="/admin/assets/js/jquery.min.js"></script>
<script src="/admin/assets/js/bootstrap.bundle.min.js"></script>
<script src="/admin/assets/js/metisMenu.min.js"></script>
<script src="/admin/assets/js/jquery.slimscroll.js"></script>
<script src="/admin/assets/js/waves.min.js"></script>
<script src="/admin/plugins/jquery-sparkline/jquery.sparkline.min.js"></script><!--Morris Chart-->
<script src="/admin/plugins/morris/morris.min.js"></script>
<script src="/admin/plugins/raphael/raphael-min.js"></script>
<script src="/admin/assets/pages/dashboard.js"></script><!-- App js -->
<script src="/admin/assets/js/app.js"></script>


<script src="/admin/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="/admin/plugins/datatables/dataTables.bootstrap4.min.js"></script><!-- Buttons examples -->
<script src="/admin/plugins/datatables/dataTables.buttons.min.js"></script>
<script src="/admin/plugins/datatables/buttons.bootstrap4.min.js"></script>
<script src="/admin/plugins/datatables/jszip.min.js"></script>
<script src="/admin/plugins/datatables/pdfmake.min.js"></script>
<script src="/admin/plugins/datatables/vfs_fonts.js"></script>
<script src="/admin/plugins/datatables/buttons.html5.min.js"></script>
<script src="/admin/plugins/datatables/buttons.print.min.js"></script>
<script src="/admin/plugins/datatables/buttons.colVis.min.js"></script><!-- Responsive examples -->
<script src="/admin/plugins/datatables/dataTables.responsive.min.js"></script>
<script src="/admin/plugins/datatables/responsive.bootstrap4.min.js"></script><!-- Datatable init js -->
<script src="/admin/assets/pages/datatables.init.js"></script><!-- App js -->