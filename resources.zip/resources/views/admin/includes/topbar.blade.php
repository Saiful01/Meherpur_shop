<div class="topbar"><!-- LOGO -->
    <div class="topbar-left"><a href="/admin/dashboard" class="logo"><span style="color:#fff">Admin </span><i><img
                        src="/admin/assets/images/logo-sm.png" alt="" height="22"></i></a></div>
    <nav class="navbar-custom">
        <ul class="navbar-right d-flex list-inline float-right mb-0">

            <li class="dropdown notification-list"><a class="nav-link dropdown-toggle arrow-none waves-effect"
                                                      data-toggle="dropdown" href="#" role="button"
                                                      aria-haspopup="false" aria-expanded="false"><i
                            class="ti-bell noti-icon"></i> <span
                            class="badge badge-pill badge-danger noti-icon-badge">3</span></a>
                <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg"><!-- item--><h6
                            class="dropdown-item-text">Notifications (258)</h6>
                    <div class="slimscroll notification-item-list"><!-- item-->
                        <a href="javascript:void(0);" class="dropdown-item notify-item active">
                            <div class="notify-icon bg-success"><i class="mdi mdi-cart-outline"></i></div>
                            <p class="notify-details">Your order is placed<span class="text-muted">Dummy text of the printing and typesetting industry.</span>
                            </p>
                        </a>
                    </div>

                </div>
            </li>
            <li class="dropdown notification-list">
                <div class="dropdown notification-list nav-pro-img"><a
                            class="dropdown-toggle nav-link arrow-none waves-effect nav-user" data-toggle="dropdown"
                            href="#" role="button" aria-haspopup="false" aria-expanded="false"><img
                                src="/admin/assets/images/users/user-4.jpg" alt="user" class="rounded-circle"></a>
                    <div class="dropdown-menu dropdown-menu-right profile-dropdown"><!-- item--> <a
                                class="dropdown-item" href="/admin/profile"><i class="mdi mdi-account-circle m-r-5"></i> Profile</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-danger" href="/admin/logout"><i
                                    class="mdi mdi-power text-danger"></i>Logout</a>
                    </div>
                </div>
            </li>
        </ul>
        <ul class="list-inline menu-left mb-0">
            <li class="float-left">
                <button class="button-menu-mobile open-left waves-effect"><i class="mdi mdi-menu"></i></button>
            </li>

        </ul>
    </nav>
</div><!-- Top Bar End --><!-- ========== Left Sidebar Start ========== -->